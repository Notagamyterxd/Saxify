# Saxify - AI Companion (Paper 1.21.11)

A commandable companion mob named **Saxify** that you spawn per-player. It
follows you, mines ore you name (with whatever tool you've equipped it with),
cleans up dirt/gravel/sand/cobblestone clutter, builds simple prebuilt
structures, guards you or attacks a target, and brings gathered items back on
request.

No NPC library (Citizens, etc.) is used — the companion is a real vanilla mob
(a Piglin by default) with `setAI(false)`, driven entirely by this plugin's own
pathfinding/target logic via `Mob#getPathfinder()`.

Commands are understood through **rule-based keyword parsing**, not a real
language model — no API key or internet connection is required at runtime,
but phrasing has to roughly match the patterns below.

---

## 1. Building the .jar

You need **Java 25** and **Maven** on the machine you build with (not
necessarily your server) and an internet connection, because Maven has to
download the Paper API the first time.

```
cd ai-companion
mvn clean package
```

That produces `target/ai-companion.jar`. That file is the plugin.

This targets **Paper 26.2** (Paper dropped the old `1.21.x-R0.1-SNAPSHOT`
versioning scheme starting with the 26.x line, and now requires a Java 25
toolchain). `pom.xml` pins the dependency to `[26.2.build,)`, which resolves
to the latest published 26.2 build — swap it for a specific build (e.g.
`26.2.build.121-stable`) in `pom.xml` if you want a fully reproducible build
instead of "always latest."

If your build environment only has Java 21 (GitHub Codespaces' default image,
for instance), install 25 first:
```
sudo apt-get update && sudo apt-get install -y openjdk-25-jdk
sudo update-alternatives --config java   # pick the 25 entry
```

Don't have Maven installed? Easiest options:
- **IntelliJ IDEA / VS Code with the Java extension**: open the folder, both
  will offer to import the Maven project and give you a "package" run
  configuration.
- **Install Maven directly**: maven.apache.org/download.cgi, unzip, add its
  `bin/` to your PATH, then run the command above.
- **GitHub**: push this folder to a repo and add a one-step GitHub Actions
  workflow (`actions/setup-java` at version 25 + `mvn -B package`) — it'll
  build the jar for you with zero local setup, downloadable from the Actions
  run's artifacts.

## 2. Deploying to a server

1. You need a **Paper** server (not vanilla, not plain Spigot — the plugin
   uses a couple of Paper-only APIs) on **version 26.2**, running on a
   **Java 25** runtime. If your host lets you pick the Java version
   separately from the Minecraft version, make sure it's set to 25 — Paper
   26.2 won't start on an older JVM.
2. Drop `ai-companion.jar` into that server's `plugins/` folder.
3. Start (or restart) the server. Check the console log for
   `AICompanion enabled. Players can run /aic spawn to get a companion.`
4. In-game, run `/aic spawn`.

That's it — no config files, no database, no external services.

## 3. Player commands

| Slash command | What happens |
|---|---|
| `/aic spawn` | Spawns Saxify bound to you (one at a time) |
| `/aic remove` | Dismisses it (drops anything it was carrying) |
| `/aic inventory` | Opens its 27-slot storage |
| `/aic status` | Shows its current state/task |
| `/aic help` | Prints the full command list in-game |

## 4. Talking to it

Chat messages starting with a trigger phrase (`hey saxify`, `saxify,`,
`hey ai`, `ai,`, `companion,`, etc.) are parsed as commands.

| Say this | Saxify does this |
|---|---|
| `hey saxify, mine some diamond` | Finds the nearest diamond ore in range, mines it with whatever's in its tool slot, repeats until told to stop or storage fills up. Also knows `iron`, `gold`, `coal`, `redstone`, `lapis`, `emerald`, `copper`, `stone`, `wood`/`log` |
| `saxify, chop some wood` | Same mining behavior, works for logs too (`chop`/`mine`/`gather`/`dig`/`get me`/`fetch me` all trigger it) |
| `saxify, clean up the dirt` | Clears dirt-type blocks (dirt, grass block, coarse dirt, podzol, mycelium) and collects the drops. Also knows `gravel`, `sand`, `cobblestone`/`cobble`, `netherrack`, `andesite` (covers andesite/diorite/granite) - or say `clean everything`/`clean this up` for all clutter types at once. Auto-stops after 200 blocks so it can't strip a whole hillside in one go |
| `saxify, build a wall` / `a house` / `a tower` | Places a built-in blueprint nearby, block by block, pulling matching materials from its own storage. Reports what it was missing |
| `saxify guard me` | Fights the nearest hostile mob within range on its own |
| `saxify guard this spot` | Stands watch at its *current location* instead of following you - useful for guarding a base while you wander off |
| `saxify attack Steve` | Targets a specific online player by name |
| `saxify come back` / `saxify give me the diamonds` | Walks to you and dumps its storage into your inventory (overflow drops on the ground) |
| `saxify drop everything` | Dumps its storage on the ground right where it's standing (handy if you don't want to walk over) |
| `saxify stop` / `saxify stay` | Cancels whatever it's doing and holds position |
| `saxify follow` / `saxify come here` | Resumes following you |
| `saxify show me your inventory` | Opens its storage GUI (same as `/aic inventory`) |
| `saxify status` | Tells you what it's currently doing |
| `saxify help` | Lists all of the above in chat |

It also fights back automatically if something attacks it, regardless of
what it was doing at the time.

## 5. Equipping tools - the inventory GUI

Right-click Saxify with an item in hand to hand it over directly, or
right-click empty-handed (or say "show me your inventory") to open its
storage GUI.

**The top-left slot (slot 1) is its held tool.** Whatever you put there is
what it mines/cleans with — take out the wooden pickaxe and drop in an iron
one, and the next diamond ore it swings at will actually drop diamonds.
Change happens live (synced roughly twice a second), no need to re-give the
item or restart a task. The other 26 slots are just general storage for
whatever it's gathered or is holding for a build.

If its tool is too weak for the ore (e.g. still a wooden pickaxe on diamond
ore), it'll still break the block — matching real Minecraft's rule that
insufficient tools destroy the block without dropping anything — and it'll
tell you once so you know to swap in something better.

## Known limitations (first version, by design)

- **Cleaning** doesn't need any particular tool — dirt-type blocks drop
  without one — but it does respect whatever's in its tool slot either way.
- **Building** only knows the 3 blueprints baked into `BlueprintLibrary`
  (`wall`, `house`, `tower`). Add more by appending to that class — each is
  just a list of relative offsets + a `Material`.
- **PvP** is manual damage application + knockback on a cooldown, not a full
  vanilla combat AI — no shield blocking, no combos, no sprint-attack crits.
- **No persistence** across server restarts: the companion (and whatever
  is in its storage) resets when the plugin reloads. Wire up
  `PersistentDataContainer` + a save/load pass in `AICompanionPlugin` if you
  want that.
- **One companion per player.** `CompanionManager` is written around a single
  `Companion` per owner UUID; supporting multiples is a small change to the
  map shape if you need it.
- The ore/clutter search scans a bounded box (capped to already-loaded
  chunks so it never forces chunk generation) every time it needs a new
  target. Turn `SEARCH_RADIUS` down in `MineTask`/`CleanTask` if you notice
  tick lag on a busy server.

## Extending it

Everything behavioral lives under `tasks/` as small classes implementing
`Task` (`tick()` + `isComplete()`). To add a new ability (e.g. "farm crops"),
write a new `Task`, add a keyword branch in `CommandInterpreter`, and a case
in `CompanionManager#handleCommand`.
