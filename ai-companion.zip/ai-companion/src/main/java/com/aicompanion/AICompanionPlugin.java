package com.aicompanion;

import com.aicompanion.commands.AICompanionCommand;
import com.aicompanion.companion.CompanionManager;
import com.aicompanion.listeners.ChatListener;
import com.aicompanion.listeners.CombatListener;
import com.aicompanion.listeners.PlayerInteractListener;
import org.bukkit.plugin.java.JavaPlugin;

public class AICompanionPlugin extends JavaPlugin {

    private CompanionManager companionManager;

    @Override
    public void onEnable() {
        companionManager = new CompanionManager(this);
        companionManager.startTicking();

        getServer().getPluginManager().registerEvents(new ChatListener(companionManager), this);
        getServer().getPluginManager().registerEvents(new PlayerInteractListener(companionManager), this);
        getServer().getPluginManager().registerEvents(new CombatListener(companionManager), this);

        var executor = new AICompanionCommand(companionManager);
        getCommand("aicompanion").setExecutor(executor);

        getLogger().info("AICompanion enabled. Players can run /aic spawn to get a companion.");
    }

    @Override
    public void onDisable() {
        // Companions are backed by real world entities; leave them in the world on reload/restart
        // rather than force-despawning, so players don't lose an in-progress task.
        getLogger().info("AICompanion disabled.");
    }

    public CompanionManager getCompanionManager() {
        return companionManager;
    }
}
