package com.aicompanion.ai;

import com.aicompanion.tasks.BlueprintLibrary;
import com.aicompanion.util.ItemUtil;

import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Very small rule-based NLU: no external API calls, just trigger-word detection
 * followed by ordered keyword matching. Good enough for short imperative
 * sentences like "hey ai, go mine some diamonds" or "ai attack Steve".
 */
public final class CommandInterpreter {

    // Recognized ways to address the companion at the start of a message.
    private static final List<String> TRIGGERS = List.of(
            "hey saxify", "saxify,", "saxify ",
            "hey ai", "hey companion", "ai,", "ai ", "companion,", "companion "
    );

    private static final Pattern ATTACK_TARGET = Pattern.compile("attack\\s+(\\w+)");

    private CommandInterpreter() {
    }

    /** Returns null if the message wasn't directed at the companion (no trigger word found). */
    public static ParsedCommand parse(String rawMessage) {
        String lower = rawMessage.trim().toLowerCase(Locale.ROOT);

        String stripped = stripTrigger(lower);
        if (stripped == null) {
            return null; // not addressed to the companion
        }

        if (containsAny(stripped, "come back", "return to me", "give me", "bring it", "hand it over")) {
            return new ParsedCommand(ParsedCommand.Type.RETURN, null);
        }

        if (containsAny(stripped, "drop everything", "dump your inventory", "empty your storage", "dump storage", "drop your storage")) {
            return new ParsedCommand(ParsedCommand.Type.DROP, null);
        }

        if (containsAny(stripped, "guard this spot", "guard here", "stay and guard", "watch this area",
                "defend this area", "hold this position", "protect this area", "protect this spot")) {
            return new ParsedCommand(ParsedCommand.Type.GUARD_HERE, null);
        }

        if (containsAny(stripped, "stop", "stay", "wait", "cancel", "hold on", "freeze")) {
            return new ParsedCommand(ParsedCommand.Type.STOP, null);
        }

        if (containsAny(stripped, "clean", "clear out", "tidy", "get rid of", "remove the dirt")) {
            String clutter = ItemUtil.findCleanWordIn(stripped);
            return new ParsedCommand(ParsedCommand.Type.CLEAN, clutter);
        }

        if (containsAny(stripped, "mine", "get me", "gather", "dig", "fetch me", "chop")) {
            String ore = ItemUtil.findOreWordIn(stripped);
            return new ParsedCommand(ParsedCommand.Type.MINE, ore);
        }

        if (containsAny(stripped, "build")) {
            String structure = BlueprintLibrary.findBlueprintNameIn(stripped);
            return new ParsedCommand(ParsedCommand.Type.BUILD, structure);
        }

        Matcher attackMatcher = ATTACK_TARGET.matcher(stripped);
        if (attackMatcher.find()) {
            return new ParsedCommand(ParsedCommand.Type.ATTACK, attackMatcher.group(1));
        }

        if (containsAny(stripped, "guard", "protect", "defend")) {
            return new ParsedCommand(ParsedCommand.Type.GUARD, null);
        }

        if (containsAny(stripped, "inventory", "what do you have", "show me your storage")) {
            return new ParsedCommand(ParsedCommand.Type.INVENTORY, null);
        }

        if (containsAny(stripped, "status", "what are you doing", "how's it going")) {
            return new ParsedCommand(ParsedCommand.Type.STATUS, null);
        }

        if (containsAny(stripped, "help", "what can you do", "list commands", "commands")) {
            return new ParsedCommand(ParsedCommand.Type.HELP, null);
        }

        if (containsAny(stripped, "follow", "come", "come here", "come to me")) {
            return new ParsedCommand(ParsedCommand.Type.FOLLOW, null);
        }

        return new ParsedCommand(ParsedCommand.Type.UNKNOWN, null);
    }

    private static String stripTrigger(String lower) {
        for (String trigger : TRIGGERS) {
            if (lower.startsWith(trigger)) {
                return lower.substring(trigger.length()).trim();
            }
        }
        return null;
    }

    private static boolean containsAny(String text, String... keywords) {
        for (String keyword : keywords) {
            if (text.contains(keyword)) return true;
        }
        return false;
    }
}
