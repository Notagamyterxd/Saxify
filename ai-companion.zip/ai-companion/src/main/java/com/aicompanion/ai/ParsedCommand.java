package com.aicompanion.ai;

public class ParsedCommand {

    public enum Type {
        FOLLOW, STOP, MINE, CLEAN, BUILD, GUARD, GUARD_HERE, ATTACK, RETURN, DROP, INVENTORY, STATUS, HELP, UNKNOWN
    }

    private final Type type;
    private final String argument; // ore keyword, structure name, or player name depending on type

    public ParsedCommand(Type type, String argument) {
        this.type = type;
        this.argument = argument;
    }

    public Type getType() {
        return type;
    }

    public String getArgument() {
        return argument;
    }
}
