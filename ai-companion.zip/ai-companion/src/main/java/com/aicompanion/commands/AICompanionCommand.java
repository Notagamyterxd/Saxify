package com.aicompanion.commands;

import com.aicompanion.companion.Companion;
import com.aicompanion.companion.CompanionManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AICompanionCommand implements CommandExecutor {

    private final CompanionManager manager;

    public AICompanionCommand(CompanionManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage("§eUsage: /aic <spawn|remove|inventory|status|help>");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "spawn" -> {
                if (manager.get(player) != null) {
                    player.sendMessage("§cYou already have a companion. Use /aic remove first.");
                    return true;
                }
                manager.spawn(player);
                player.sendMessage("§dSaxify has arrived! Give it a pickaxe/tools, "
                        + "then talk to it: \"hey saxify, mine some diamond\" or \"saxify, clean up the dirt\".");
            }
            case "remove" -> {
                if (manager.get(player) == null) {
                    player.sendMessage("§cYou don't have a companion.");
                    return true;
                }
                manager.remove(player);
                player.sendMessage("§aCompanion dismissed. Anything it was carrying was dropped on the ground.");
            }
            case "inventory", "inv" -> {
                Companion companion = manager.get(player);
                if (companion == null) {
                    player.sendMessage("§cYou don't have a companion.");
                    return true;
                }
                player.openInventory(companion.getStorage());
            }
            case "status" -> {
                Companion companion = manager.get(player);
                if (companion == null) {
                    player.sendMessage("§cYou don't have a companion.");
                    return true;
                }
                player.sendMessage("§bState: " + companion.getState()
                        + " | Task: " + (companion.getCurrentTask() != null ? companion.getCurrentTask().getName() : "none"));
            }
            case "help" -> {
                Companion companion = manager.get(player);
                if (companion == null) {
                    player.sendMessage("§cYou don't have a companion yet. Try /aic spawn first.");
                    return true;
                }
                manager.handleCommand(companion, new com.aicompanion.ai.ParsedCommand(
                        com.aicompanion.ai.ParsedCommand.Type.HELP, null));
            }
            default -> player.sendMessage("§eUsage: /aic <spawn|remove|inventory|status|help>");
        }
        return true;
    }
}
