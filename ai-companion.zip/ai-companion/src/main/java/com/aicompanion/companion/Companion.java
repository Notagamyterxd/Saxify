package com.aicompanion.companion;

import com.aicompanion.tasks.Task;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/**
 * Wraps a live Mob entity and all of the bookkeeping needed to treat it
 * as a controllable companion: which player owns it, what it's doing,
 * and a small personal storage inventory for gathered/held items.
 */
public class Companion {

    private final UUID entityId;
    private final UUID ownerId;
    private CompanionState state = CompanionState.IDLE;
    private Task currentTask;
    private final Inventory storage;
    private Location guardPost; // where to return to / stand watch near
    private long lastCommandTime = 0L;

    public Companion(UUID entityId, UUID ownerId) {
        this.entityId = entityId;
        this.ownerId = ownerId;
        this.storage = Bukkit.createInventory(null, 27, "§dSaxify §7| top-left slot = held tool");
    }

    public UUID getEntityId() {
        return entityId;
    }

    public UUID getOwnerId() {
        return ownerId;
    }

    public Mob getEntity() {
        var entity = Bukkit.getEntity(entityId);
        return (entity instanceof Mob mob) ? mob : null;
    }

    public Player getOwner() {
        return Bukkit.getPlayer(ownerId);
    }

    public boolean isValid() {
        Mob mob = getEntity();
        return mob != null && !mob.isDead() && mob.isValid();
    }

    public CompanionState getState() {
        return state;
    }

    public void setState(CompanionState state) {
        this.state = state;
    }

    public Task getCurrentTask() {
        return currentTask;
    }

    /** Replaces the active task, cancelling whatever was running before. */
    public void setTask(Task task) {
        if (this.currentTask != null) {
            this.currentTask.onCancel(this);
        }
        this.currentTask = task;
    }

    /** The item in storage slot 0 is treated as the companion's active held tool. */
    public ItemStack getTool() {
        ItemStack tool = storage.getItem(0);
        return tool != null ? tool : new ItemStack(org.bukkit.Material.AIR);
    }

    public void setTool(ItemStack tool) {
        storage.setItem(0, tool);
    }

    public Inventory getStorage() {
        return storage;
    }

    /**
     * Adds an item to storage (slots 1-26 only - slot 0 is reserved for the held tool),
     * returns leftover that didn't fit (empty if all fit).
     */
    public ItemStack addToStorage(ItemStack item) {
        ItemStack remaining = item.clone();

        // First pass: top up any existing partial stacks of the same material.
        for (int i = 1; i < storage.getSize() && remaining.getAmount() > 0; i++) {
            ItemStack slot = storage.getItem(i);
            if (slot != null && slot.isSimilar(remaining)) {
                int space = slot.getMaxStackSize() - slot.getAmount();
                if (space > 0) {
                    int move = Math.min(space, remaining.getAmount());
                    slot.setAmount(slot.getAmount() + move);
                    remaining.setAmount(remaining.getAmount() - move);
                }
            }
        }

        // Second pass: place whatever's left into empty slots.
        for (int i = 1; i < storage.getSize() && remaining.getAmount() > 0; i++) {
            if (storage.getItem(i) == null) {
                int stackSize = Math.min(remaining.getMaxStackSize(), remaining.getAmount());
                ItemStack toPlace = remaining.clone();
                toPlace.setAmount(stackSize);
                storage.setItem(i, toPlace);
                remaining.setAmount(remaining.getAmount() - stackSize);
            }
        }

        if (remaining.getAmount() <= 0) {
            return new ItemStack(org.bukkit.Material.AIR);
        }
        return remaining;
    }

    public boolean isStorageFull() {
        for (int i = 1; i < storage.getSize(); i++) {
            if (storage.getItem(i) == null) return false;
        }
        return true;
    }

    public Location getGuardPost() {
        return guardPost;
    }

    public void setGuardPost(Location guardPost) {
        this.guardPost = guardPost;
    }

    public void notifyOwner(String message) {
        Player owner = getOwner();
        if (owner != null) {
            owner.sendMessage("§d[Saxify]§r " + message);
        }
    }

    public long getLastCommandTime() {
        return lastCommandTime;
    }

    public void setLastCommandTime(long lastCommandTime) {
        this.lastCommandTime = lastCommandTime;
    }
}
