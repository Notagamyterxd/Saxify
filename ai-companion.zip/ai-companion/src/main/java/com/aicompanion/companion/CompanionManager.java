package com.aicompanion.companion;

import com.aicompanion.ai.ParsedCommand;
import com.aicompanion.tasks.*;
import com.aicompanion.util.ItemUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Piglin;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class CompanionManager {

    private final JavaPlugin plugin;
    private final Map<UUID, Companion> companionsByOwner = new HashMap<>();
    private final Map<UUID, UUID> ownerByEntity = new HashMap<>(); // entityId -> ownerId

    public CompanionManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void startTicking() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::tickAll, 10L, 10L);
    }

    private void tickAll() {
        for (Companion companion : companionsByOwner.values()) {
            if (!companion.isValid()) continue;

            syncHeldTool(companion);

            if (companion.getCurrentTask() == null) {
                companion.setTask(new FollowTask());
                companion.setState(CompanionState.FOLLOWING);
            }

            Task task = companion.getCurrentTask();
            task.tick(companion);

            if (task.isComplete(companion)) {
                companion.setTask(new FollowTask());
                companion.setState(CompanionState.FOLLOWING);
            }
        }
    }

    /** Slot 0 of the companion's storage GUI is the single source of truth for its held tool. */
    private void syncHeldTool(Companion companion) {
        Mob mob = companion.getEntity();
        if (mob == null || mob.getEquipment() == null) return;
        var tool = companion.getTool();
        if (!mob.getEquipment().getItemInMainHand().isSimilar(tool)) {
            mob.getEquipment().setItemInMainHand(tool.getType() == org.bukkit.Material.AIR ? null : tool);
        }
    }

    public Companion spawn(Player owner) {
        remove(owner); // only one companion per player at a time

        Location loc = owner.getLocation();
        Mob mob = (Mob) loc.getWorld().spawnEntity(loc, org.bukkit.entity.EntityType.PIGLIN);
        mob.setAI(false); // we drive all movement/targeting manually
        mob.setRemoveWhenFarAway(false);
        mob.setPersistent(true);
        mob.setCustomName("§dSaxify§r");
        mob.setCustomNameVisible(true);
        mob.setCanPickupItems(false);

        if (mob instanceof Piglin piglin) {
            piglin.setImmuneToZombification(true);
            piglin.setBaby(false);
        }
        if (mob.getEquipment() != null) {
            mob.getEquipment().setItemInMainHandDropChance(0f);
            mob.getEquipment().setHelmetDropChance(0f);
        }

        Companion companion = new Companion(mob.getUniqueId(), owner.getUniqueId());
        companion.setTask(new FollowTask());
        companion.setState(CompanionState.FOLLOWING);

        companionsByOwner.put(owner.getUniqueId(), companion);
        ownerByEntity.put(mob.getUniqueId(), owner.getUniqueId());
        return companion;
    }

    public void remove(Player owner) {
        Companion existing = companionsByOwner.remove(owner.getUniqueId());
        if (existing != null) {
            ownerByEntity.remove(existing.getEntityId());
            Mob mob = existing.getEntity();
            if (mob != null) {
                for (var stack : existing.getStorage().getContents()) {
                    if (stack != null && !stack.getType().isAir()) {
                        mob.getWorld().dropItemNaturally(mob.getLocation(), stack);
                    }
                }
                mob.remove();
            }
        }
    }

    public Companion get(Player owner) {
        return companionsByOwner.get(owner.getUniqueId());
    }

    public Companion getByEntity(UUID entityId) {
        UUID ownerId = ownerByEntity.get(entityId);
        return ownerId != null ? companionsByOwner.get(ownerId) : null;
    }

    /** Applies a parsed voice/chat command to a specific companion. */
    public void handleCommand(Companion companion, ParsedCommand command) {
        switch (command.getType()) {
            case FOLLOW -> {
                companion.setTask(new FollowTask());
                companion.setState(CompanionState.FOLLOWING);
                companion.notifyOwner("On my way!");
            }
            case STOP -> {
                companion.setTask(new FollowTask());
                companion.setState(CompanionState.IDLE);
                companion.notifyOwner("Okay, holding position.");
            }
            case RETURN -> {
                companion.setTask(new ReturnTask());
                companion.setState(CompanionState.RETURNING);
                companion.notifyOwner("Bringing it back to you.");
            }
            case MINE -> {
                if (command.getArgument() == null) {
                    companion.notifyOwner("What should I mine? Try 'diamond', 'iron', 'coal', etc.");
                    return;
                }
                List<org.bukkit.Material> ores = ItemUtil.resolveOreKeyword(command.getArgument());
                if (ores == null) {
                    companion.notifyOwner("I don't know how to find '" + command.getArgument() + "'.");
                    return;
                }
                companion.setTask(new MineTask(ores, command.getArgument()));
                companion.setState(CompanionState.MINING);
                companion.notifyOwner("Looking for " + command.getArgument() + "...");
            }
            case CLEAN -> {
                List<org.bukkit.Material> clutter = ItemUtil.resolveCleanKeyword(command.getArgument());
                String label = command.getArgument() != null ? command.getArgument() : "clutter";
                Player owner = companion.getOwner();
                companion.setTask(new CleanTask(clutter, label, owner != null ? owner.getLocation() : null));
                companion.setState(CompanionState.CLEANING);
                companion.notifyOwner("On it - cleaning up the " + label + " around here.");
            }
            case BUILD -> {
                if (command.getArgument() == null) {
                    companion.notifyOwner("What should I build? I know: wall, house, tower.");
                    return;
                }
                Blueprint blueprint = BlueprintLibrary.get(command.getArgument());
                if (blueprint == null) {
                    companion.notifyOwner("I don't have a blueprint for '" + command.getArgument() + "'.");
                    return;
                }
                Player owner = companion.getOwner();
                Location anchor = buildAnchor(owner);
                companion.setTask(new BuildTask(blueprint, anchor));
                companion.setState(CompanionState.BUILDING);
                companion.notifyOwner("Building a " + command.getArgument() + " nearby. Make sure I have the blocks!");
            }
            case GUARD -> {
                companion.setTask(new GuardTask());
                companion.setState(CompanionState.GUARDING);
                companion.notifyOwner("I've got your back.");
            }
            case GUARD_HERE -> {
                Mob mob = companion.getEntity();
                Location post = mob != null ? mob.getLocation() : null;
                companion.setGuardPost(post);
                companion.setTask(new GuardTask(post));
                companion.setState(CompanionState.GUARDING);
                companion.notifyOwner("Holding this position and watching for trouble.");
            }
            case DROP -> {
                Mob mob = companion.getEntity();
                if (mob == null) return;
                var storage = companion.getStorage();
                int dropped = 0;
                for (int i = 1; i < storage.getSize(); i++) {
                    var stack = storage.getItem(i);
                    if (stack != null && !stack.getType().isAir()) {
                        mob.getWorld().dropItemNaturally(mob.getLocation(), stack);
                        storage.setItem(i, null);
                        dropped++;
                    }
                }
                companion.notifyOwner(dropped > 0 ? "Dropped everything I was carrying." : "I wasn't carrying anything.");
            }
            case ATTACK -> {
                Player targetPlayer = Bukkit.getPlayerExact(command.getArgument());
                if (targetPlayer == null) {
                    companion.notifyOwner("I can't find anyone named '" + command.getArgument() + "'.");
                    return;
                }
                companion.setTask(new GuardTask(targetPlayer.getUniqueId()));
                companion.setState(CompanionState.FIGHTING);
                companion.notifyOwner("Attacking " + targetPlayer.getName() + "!");
            }
            case INVENTORY -> {
                Player owner = companion.getOwner();
                if (owner != null) owner.openInventory(companion.getStorage());
            }
            case STATUS -> companion.notifyOwner("Current task: " + companion.getCurrentTask().getName());
            case HELP -> {
                Player owner = companion.getOwner();
                if (owner != null) {
                    owner.sendMessage("§d§l--- Saxify can... ---");
                    owner.sendMessage("§d follow §7/ §dcome here §7- follows you around");
                    owner.sendMessage("§d stop §7/ §dstay §7- holds position, cancels current task");
                    owner.sendMessage("§d mine <ore> §7- e.g. \"mine diamond\", \"get me some iron\", \"chop wood\"");
                    owner.sendMessage("§d clean <dirt/gravel/sand/cobblestone/...> §7- or just \"clean everything\"");
                    owner.sendMessage("§d build <wall/house/tower> §7- needs matching blocks in its storage");
                    owner.sendMessage("§d guard me §7- fights nearby hostiles automatically");
                    owner.sendMessage("§d guard this spot §7- stands watch at its current location");
                    owner.sendMessage("§d attack <player> §7- targets a specific online player");
                    owner.sendMessage("§d come back §7/ §dgive me the... §7- returns and hands over its storage");
                    owner.sendMessage("§d drop everything §7- dumps its storage on the ground right there");
                    owner.sendMessage("§d show me your inventory §7- opens its storage GUI (slot 1 = held tool)");
                    owner.sendMessage("§d status §7- tells you what it's currently doing");
                    owner.sendMessage("§7Right-click Saxify with an item to hand it over, or empty-handed to open its storage.");
                }
            }
            case UNKNOWN -> companion.notifyOwner("I didn't understand that. Say 'hey saxify, help' for a full list.");
        }
    }

    private Location buildAnchor(Player owner) {
        if (owner == null) return null;
        Location loc = owner.getLocation().clone();
        var dir = loc.getDirection().setY(0).normalize().multiply(3);
        loc.add(dir);
        loc.setY(owner.getLocation().getY());
        return loc.getBlock().getLocation().add(0.5, 0, 0.5);
    }

    public Map<UUID, Companion> getAll() {
        return companionsByOwner;
    }
}
