package com.aicompanion.companion;

public enum CompanionState {
    IDLE,
    FOLLOWING,
    MINING,
    CLEANING,
    BUILDING,
    GUARDING,
    FIGHTING,
    RETURNING
}
