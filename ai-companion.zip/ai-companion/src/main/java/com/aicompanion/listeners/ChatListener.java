package com.aicompanion.listeners;

import com.aicompanion.ai.CommandInterpreter;
import com.aicompanion.ai.ParsedCommand;
import com.aicompanion.companion.Companion;
import com.aicompanion.companion.CompanionManager;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class ChatListener implements Listener {

    private final CompanionManager manager;

    public ChatListener(CompanionManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onChat(AsyncChatEvent event) {
        String message = PlainTextComponentSerializer.plainText().serialize(event.message());

        Companion companion = manager.get(event.getPlayer());
        if (companion == null) return; // player has no companion, don't touch chat

        ParsedCommand parsed = CommandInterpreter.parse(message);
        if (parsed == null) return; // message wasn't addressed to the companion

        event.setCancelled(true); // consume it so it doesn't also show as normal chat
        Bukkit.getScheduler().runTask(
                Bukkit.getPluginManager().getPlugin("AICompanion"),
                () -> manager.handleCommand(companion, parsed)
        );
    }
}
