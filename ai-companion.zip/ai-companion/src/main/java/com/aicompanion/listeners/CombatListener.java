package com.aicompanion.listeners;

import com.aicompanion.companion.Companion;
import com.aicompanion.companion.CompanionManager;
import com.aicompanion.companion.CompanionState;
import com.aicompanion.tasks.GuardTask;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class CombatListener implements Listener {

    private final CompanionManager manager;

    public CombatListener(CompanionManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onCompanionDamaged(EntityDamageByEntityEvent event) {
        Companion companion = manager.getByEntity(event.getEntity().getUniqueId());
        if (companion == null) return;
        if (companion.getState() == CompanionState.FIGHTING || companion.getState() == CompanionState.GUARDING) {
            return; // already handling combat
        }
        if (!(event.getDamager() instanceof LivingEntity attacker)) return;

        companion.setTask(new GuardTask(attacker.getUniqueId()));
        companion.setState(CompanionState.FIGHTING);
        companion.notifyOwner("Something attacked me, fighting back!");
    }
}
