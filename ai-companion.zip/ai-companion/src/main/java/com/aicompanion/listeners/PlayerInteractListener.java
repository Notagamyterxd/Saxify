package com.aicompanion.listeners;

import com.aicompanion.companion.Companion;
import com.aicompanion.companion.CompanionManager;
import org.bukkit.Material;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class PlayerInteractListener implements Listener {

    private final CompanionManager manager;

    public PlayerInteractListener(CompanionManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return; // avoid double-firing for off-hand

        Companion companion = manager.getByEntity(event.getRightClicked().getUniqueId());
        if (companion == null) return;

        event.setCancelled(true);
        Player player = event.getPlayer();

        if (!companion.getOwnerId().equals(player.getUniqueId())) {
            player.sendMessage("§cThat's not your companion.");
            return;
        }

        Mob mob = companion.getEntity();
        if (mob == null) return;

        ItemStack handItem = player.getInventory().getItemInMainHand();

        if (handItem == null || handItem.getType() == Material.AIR) {
            player.openInventory(companion.getStorage());
            return;
        }

        ItemStack toGive = handItem.clone();
        toGive.setAmount(1);
        ItemStack currentlyHeld = companion.getTool();

        companion.setTool(toGive);
        handItem.setAmount(handItem.getAmount() - 1);
        if (handItem.getAmount() <= 0) {
            player.getInventory().setItemInMainHand(null);
        }

        if (currentlyHeld != null && currentlyHeld.getType() != Material.AIR) {
            var leftover = player.getInventory().addItem(currentlyHeld);
            leftover.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
        }

        player.sendMessage("§bGave Saxify: " + toGive.getType());
    }
}
