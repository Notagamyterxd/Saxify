package com.aicompanion.tasks;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.List;

/** A relative-offset block plan the companion can build, anchored on the spot it was told to build. */
public class Blueprint {

    public record BlockSpec(int dx, int dy, int dz, Material material) {
    }

    private final String name;
    private final List<BlockSpec> blocks = new ArrayList<>();

    public Blueprint(String name) {
        this.name = name;
    }

    public Blueprint add(int dx, int dy, int dz, Material material) {
        blocks.add(new BlockSpec(dx, dy, dz, material));
        return this;
    }

    public List<BlockSpec> getBlocks() {
        return blocks;
    }

    public String getName() {
        return name;
    }
}
