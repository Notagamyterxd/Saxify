package com.aicompanion.tasks;

import org.bukkit.Material;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class BlueprintLibrary {

    private static final Map<String, Blueprint> BLUEPRINTS = new HashMap<>();

    static {
        // A 5-wide, 3-tall wall, one block thick, using cobblestone.
        Blueprint wall = new Blueprint("wall");
        for (int x = -2; x <= 2; x++) {
            for (int y = 0; y <= 2; y++) {
                wall.add(x, y, 0, Material.COBBLESTONE);
            }
        }
        BLUEPRINTS.put("wall", wall);

        // A simple 5x5 hollow-box "house" with a doorway, oak planks walls, no roof (kept simple on purpose).
        Blueprint house = new Blueprint("house");
        int size = 5;
        int height = 4;
        for (int x = -size / 2; x <= size / 2; x++) {
            for (int z = -size / 2; z <= size / 2; z++) {
                boolean edge = (x == -size / 2 || x == size / 2 || z == -size / 2 || z == size / 2);
                if (!edge) continue;
                for (int y = 0; y < height; y++) {
                    boolean isDoor = (x == 0 && z == -size / 2 && (y == 0 || y == 1));
                    if (isDoor) continue;
                    house.add(x, y, z, Material.OAK_PLANKS);
                }
            }
        }
        BLUEPRINTS.put("house", house);

        // A 1x1 tower, 8 blocks tall.
        Blueprint tower = new Blueprint("tower");
        for (int y = 0; y < 8; y++) {
            tower.add(0, y, 0, Material.STONE_BRICKS);
        }
        BLUEPRINTS.put("tower", tower);
    }

    private BlueprintLibrary() {
    }

    public static Blueprint get(String name) {
        return BLUEPRINTS.get(name.toLowerCase(Locale.ROOT));
    }

    /** Scans free-form text for the first recognized blueprint name, or null. */
    public static String findBlueprintNameIn(String text) {
        String lower = text.toLowerCase(Locale.ROOT);
        for (String name : BLUEPRINTS.keySet()) {
            if (lower.contains(name)) {
                return name;
            }
        }
        return null;
    }
}
