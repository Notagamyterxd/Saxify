package com.aicompanion.tasks;

import com.aicompanion.companion.Companion;
import com.aicompanion.util.PathfindUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Mob;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayDeque;
import java.util.Deque;

public class BuildTask implements Task {

    private static final double REACH = 4.0;
    private static final double SPEED = 1.0;

    private final Blueprint blueprint;
    private final Location anchor;
    private final Deque<Blueprint.BlockSpec> remaining = new ArrayDeque<>();
    private boolean complete = false;
    private int placed = 0;
    private int skippedMissingMaterial = 0;

    public BuildTask(Blueprint blueprint, Location anchor) {
        this.blueprint = blueprint;
        this.anchor = anchor;
        this.remaining.addAll(blueprint.getBlocks());
    }

    @Override
    public void tick(Companion companion) {
        Mob mob = companion.getEntity();
        if (mob == null) {
            complete = true;
            return;
        }

        if (remaining.isEmpty()) {
            finish(companion);
            return;
        }

        Blueprint.BlockSpec spec = remaining.peek();
        Location target = anchor.clone().add(spec.dx(), spec.dy(), spec.dz());

        double dist = mob.getLocation().distance(target);
        if (dist > REACH) {
            PathfindUtil.moveTo(mob, target, SPEED);
            return;
        }

        PathfindUtil.stop(mob);
        PathfindUtil.lookAt(mob, target);
        placeBlock(companion, target, spec.material());
        remaining.poll();
    }

    private void placeBlock(Companion companion, Location target, Material material) {
        if (!target.getBlock().getType().isAir()) {
            return; // don't overwrite existing terrain/blocks
        }

        Inventory storage = companion.getStorage();
        int foundSlot = -1;
        for (int i = 0; i < storage.getSize(); i++) {
            ItemStack stack = storage.getItem(i);
            if (stack != null && stack.getType() == material) {
                foundSlot = i;
                break;
            }
        }

        if (foundSlot == -1) {
            skippedMissingMaterial++;
            return;
        }

        target.getBlock().setType(material);
        ItemStack stack = storage.getItem(foundSlot);
        stack.setAmount(stack.getAmount() - 1);
        storage.setItem(foundSlot, stack.getAmount() <= 0 ? null : stack);
        placed++;
    }

    private void finish(Companion companion) {
        complete = true;
        String msg = "Finished building the " + blueprint.getName() + "! Placed " + placed + " blocks.";
        if (skippedMissingMaterial > 0) {
            msg += " I was missing materials for " + skippedMissingMaterial + " of them.";
        }
        companion.notifyOwner(msg);
    }

    @Override
    public boolean isComplete(Companion companion) {
        return complete;
    }

    @Override
    public String getName() {
        return "Building " + blueprint.getName();
    }

    @Override
    public void onCancel(Companion companion) {
        companion.notifyOwner("Stopping construction on the " + blueprint.getName() + ".");
    }
}
