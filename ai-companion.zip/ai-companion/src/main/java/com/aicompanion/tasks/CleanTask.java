package com.aicompanion.tasks;

import com.aicompanion.companion.Companion;
import com.aicompanion.util.PathfindUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Item;
import org.bukkit.entity.Mob;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * Clears clutter blocks (dirt, gravel, sand, cobblestone, etc.) from around a
 * point. Unlike MineTask this never checks tool tier - dirt-type blocks don't
 * need one - it'll use whatever's in hand (or bare hands) either way.
 */
public class CleanTask implements Task {

    private static final double REACH = 3.2;
    private static final double SPEED = 1.0;
    private static final int SEARCH_RADIUS = 14;
    private static final int SEARCH_HEIGHT = 6; // clutter is almost always near surface level
    private static final int MAX_BLOCKS_PER_RUN = 200; // safety cap so it doesn't strip an entire mountain

    private final List<Material> clutterTypes;
    private final String spokenName;
    private final Location anchor;
    private Location targetBlockLoc;
    private boolean complete = false;
    private int cleared = 0;

    public CleanTask(List<Material> clutterTypes, String spokenName, Location anchor) {
        this.clutterTypes = clutterTypes;
        this.spokenName = spokenName;
        this.anchor = anchor;
    }

    @Override
    public void tick(Companion companion) {
        Mob mob = companion.getEntity();
        if (mob == null) {
            complete = true;
            return;
        }

        if (cleared >= MAX_BLOCKS_PER_RUN) {
            companion.notifyOwner("Cleared " + cleared + " blocks of " + spokenName + ". That's a good chunk done - tell me again if there's more.");
            complete = true;
            return;
        }

        if (companion.isStorageFull()) {
            companion.notifyOwner("My storage is full. Say 'come back' so I can drop this off, then send me to clean more.");
            complete = true;
            return;
        }

        if (targetBlockLoc == null || !matchesClutter(targetBlockLoc)) {
            targetBlockLoc = findNearestClutter(anchor != null ? anchor : mob.getLocation());
            if (targetBlockLoc == null) {
                companion.notifyOwner(cleared > 0
                        ? "All clean! Cleared " + cleared + " blocks of " + spokenName + "."
                        : "I don't see any " + spokenName + " nearby to clean up.");
                complete = true;
                return;
            }
        }

        double dist = mob.getLocation().distance(targetBlockLoc);
        if (dist > REACH) {
            PathfindUtil.moveTo(mob, targetBlockLoc, SPEED);
            return;
        }

        PathfindUtil.stop(mob);
        PathfindUtil.lookAt(mob, targetBlockLoc);
        clearBlock(companion, targetBlockLoc);
        targetBlockLoc = null;
    }

    private boolean matchesClutter(Location loc) {
        return clutterTypes.contains(loc.getBlock().getType());
    }

    private void clearBlock(Companion companion, Location loc) {
        Block block = loc.getBlock();
        World world = block.getWorld();

        ItemStack tool = companion.getTool();

        boolean broke = block.breakNaturally(tool);
        if (!broke) return;
        cleared++;

        for (Item itemEntity : world.getNearbyEntitiesByType(Item.class, loc.clone().add(0.5, 0.5, 0.5), 2, 2, 2)) {
            ItemStack drop = itemEntity.getItemStack();
            ItemStack leftover = companion.addToStorage(drop);
            if (leftover.getType() == Material.AIR || leftover.getAmount() == 0) {
                itemEntity.remove();
            } else {
                itemEntity.setItemStack(leftover);
            }
        }
    }

    private Location findNearestClutter(Location origin) {
        World world = origin.getWorld();
        if (world == null) return null;

        Location best = null;
        double bestDist = Double.MAX_VALUE;
        int baseX = origin.getBlockX();
        int baseY = origin.getBlockY();
        int baseZ = origin.getBlockZ();

        for (int dx = -SEARCH_RADIUS; dx <= SEARCH_RADIUS; dx++) {
            for (int dz = -SEARCH_RADIUS; dz <= SEARCH_RADIUS; dz++) {
                int x = baseX + dx;
                int z = baseZ + dz;
                if (!world.isChunkLoaded(x >> 4, z >> 4)) continue;

                for (int dy = -SEARCH_HEIGHT; dy <= SEARCH_HEIGHT; dy++) {
                    int y = baseY + dy;
                    if (y < world.getMinHeight() || y >= world.getMaxHeight()) continue;

                    Material type = world.getBlockAt(x, y, z).getType();
                    if (clutterTypes.contains(type)) {
                        double d = (dx * dx) + (dy * dy) + (dz * dz);
                        if (d < bestDist) {
                            bestDist = d;
                            best = new Location(world, x + 0.5, y, z + 0.5);
                        }
                    }
                }
            }
        }
        return best;
    }

    @Override
    public boolean isComplete(Companion companion) {
        return complete;
    }

    @Override
    public String getName() {
        return "Cleaning up " + spokenName;
    }

    @Override
    public void onCancel(Companion companion) {
        companion.notifyOwner("Stopping the clean-up. Cleared " + cleared + " blocks so far.");
    }
}
