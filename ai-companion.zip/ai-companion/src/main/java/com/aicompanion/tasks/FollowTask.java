package com.aicompanion.tasks;

import com.aicompanion.companion.Companion;
import com.aicompanion.util.PathfindUtil;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;

public class FollowTask implements Task {

    private static final double FOLLOW_DISTANCE = 3.0;
    private static final double TELEPORT_DISTANCE = 40.0; // too far away, snap to owner instead of walking
    private static final double SPEED = 1.0;

    @Override
    public void tick(Companion companion) {
        Mob mob = companion.getEntity();
        Player owner = companion.getOwner();
        if (mob == null || owner == null) return;

        double distance = mob.getLocation().distance(owner.getLocation());

        if (distance > TELEPORT_DISTANCE) {
            mob.teleport(owner.getLocation());
            return;
        }

        if (distance > FOLLOW_DISTANCE) {
            PathfindUtil.moveTo(mob, owner.getLocation(), SPEED);
        } else {
            PathfindUtil.stop(mob);
            PathfindUtil.lookAt(mob, owner.getLocation());
        }
    }

    @Override
    public boolean isComplete(Companion companion) {
        return false; // following runs indefinitely until replaced by another task
    }

    @Override
    public String getName() {
        return "Following";
    }
}
