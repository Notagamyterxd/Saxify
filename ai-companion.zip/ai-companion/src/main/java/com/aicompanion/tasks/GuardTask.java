package com.aicompanion.tasks;

import com.aicompanion.companion.Companion;
import com.aicompanion.util.PathfindUtil;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

public class GuardTask implements Task {

    private static final double GUARD_RADIUS = 12.0;
    private static final double ATTACK_RANGE = 2.2;
    private static final double CHASE_SPEED = 1.15;
    private static final double DAMAGE_PER_HIT = 4.0;
    private static final long HIT_COOLDOWN_MS = 700;

    private UUID forcedTargetId; // set when player said "attack <name>", otherwise auto-detect hostiles
    private final Location fixedPost; // set when told to guard a specific spot instead of following the owner
    private long lastHitTime = 0L;

    public GuardTask() {
        this.forcedTargetId = null;
        this.fixedPost = null;
    }

    public GuardTask(UUID forcedTargetId) {
        this.forcedTargetId = forcedTargetId;
        this.fixedPost = null;
    }

    public GuardTask(Location fixedPost) {
        this.forcedTargetId = null;
        this.fixedPost = fixedPost;
    }

    @Override
    public void tick(Companion companion) {
        Mob mob = companion.getEntity();
        Player owner = companion.getOwner();
        if (mob == null) return;

        LivingEntity target = resolveTarget(companion, mob, owner);

        if (target == null) {
            // Nothing to fight: hover near the guard point (fixed spot, or the owner if none was set).
            Location anchor = fixedPost != null ? fixedPost : (owner != null ? owner.getLocation() : null);
            if (anchor != null) {
                double d = mob.getLocation().distance(anchor);
                if (d > GUARD_RADIUS / 2.0) {
                    PathfindUtil.moveTo(mob, anchor, 1.0);
                } else {
                    PathfindUtil.stop(mob);
                }
            }
            return;
        }

        double dist = mob.getLocation().distance(target.getLocation());
        if (dist > ATTACK_RANGE) {
            PathfindUtil.moveTo(mob, target.getLocation(), CHASE_SPEED);
        } else {
            PathfindUtil.stop(mob);
            PathfindUtil.lookAt(mob, target.getLocation());
            attack(mob, target);
        }
    }

    private LivingEntity resolveTarget(Companion companion, Mob mob, Player owner) {
        if (forcedTargetId != null) {
            var entity = org.bukkit.Bukkit.getEntity(forcedTargetId);
            if (entity instanceof LivingEntity le && !le.isDead()) {
                return le;
            }
            forcedTargetId = null; // target died or left, fall back to auto-detect
        }

        Location center = fixedPost != null ? fixedPost : (owner != null ? owner.getLocation() : mob.getLocation());
        List<Monster> nearby = mob.getWorld().getNearbyEntitiesByType(Monster.class, center, GUARD_RADIUS)
                .stream()
                .filter(m -> !m.isDead())
                .sorted(Comparator.comparingDouble(m -> m.getLocation().distanceSquared(mob.getLocation())))
                .toList();
        return nearby.isEmpty() ? null : nearby.get(0);
    }

    private void attack(Mob mob, LivingEntity target) {
        long now = System.currentTimeMillis();
        if (now - lastHitTime < HIT_COOLDOWN_MS) return;
        lastHitTime = now;

        target.damage(DAMAGE_PER_HIT, mob);
        org.bukkit.util.Vector knockback = target.getLocation().toVector()
                .subtract(mob.getLocation().toVector()).normalize().multiply(0.35).setY(0.1);
        target.setVelocity(target.getVelocity().add(knockback));
        mob.getWorld().playSound(mob.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 1.0f);
    }

    @Override
    public boolean isComplete(Companion companion) {
        return false; // guarding runs until the player gives a new command
    }

    @Override
    public String getName() {
        if (forcedTargetId != null) return "Attacking target";
        return fixedPost != null ? "Guarding this spot" : "Guarding";
    }

    @Override
    public void onCancel(Companion companion) {
        companion.notifyOwner("Standing down.");
    }
}
