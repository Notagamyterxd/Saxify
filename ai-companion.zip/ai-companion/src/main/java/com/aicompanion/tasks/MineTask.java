package com.aicompanion.tasks;

import com.aicompanion.companion.Companion;
import com.aicompanion.util.ItemUtil;
import com.aicompanion.util.PathfindUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Item;
import org.bukkit.entity.Mob;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;

import java.util.List;

public class MineTask implements Task {

    private static final double REACH = 3.2;
    private static final double SPEED = 1.0;
    private static final int SEARCH_RADIUS = 20;
    private static final int MAX_BLOCKS_PER_SEARCH_Y = 20;

    private final List<Material> oreTypes;
    private final String spokenName;
    private Location targetBlockLoc;
    private boolean complete = false;
    private boolean reportedWeakTool = false;

    public MineTask(List<Material> oreTypes, String spokenName) {
        this.oreTypes = oreTypes;
        this.spokenName = spokenName;
    }

    @Override
    public void tick(Companion companion) {
        Mob mob = companion.getEntity();
        if (mob == null) {
            complete = true;
            return;
        }

        if (companion.isStorageFull()) {
            companion.notifyOwner("My storage is full of " + spokenName + " and other goods. Say 'come back' when you want it.");
            complete = true;
            return;
        }

        if (targetBlockLoc == null || !matchesOre(targetBlockLoc)) {
            targetBlockLoc = findNearestOre(mob.getLocation());
            if (targetBlockLoc == null) {
                companion.notifyOwner("I couldn't find any " + spokenName + " nearby. Try somewhere else.");
                complete = true;
                return;
            }
        }

        double dist = mob.getLocation().distance(targetBlockLoc);
        if (dist > REACH) {
            PathfindUtil.moveTo(mob, targetBlockLoc, SPEED);
            return;
        }

        PathfindUtil.stop(mob);
        PathfindUtil.lookAt(mob, targetBlockLoc);
        mineBlock(companion, mob, targetBlockLoc);
        targetBlockLoc = null; // force re-search next tick for the next ore
    }

    private boolean matchesOre(Location loc) {
        Block block = loc.getBlock();
        return oreTypes.contains(block.getType());
    }

    private void mineBlock(Companion companion, Mob mob, Location loc) {
        Block block = loc.getBlock();
        World world = block.getWorld();
        Material oreType = block.getType();
        ItemStack tool = companion.getTool(); // AIR if nothing equipped - still allowed, just like mining bare-handed

        boolean broke = block.breakNaturally(tool);
        if (!broke) return;

        damageTool(companion, tool);

        // Sweep up nearby dropped items into companion storage.
        int itemsCollected = 0;
        for (Item itemEntity : world.getNearbyEntitiesByType(Item.class, loc.clone().add(0.5, 0.5, 0.5), 2, 2, 2)) {
            ItemStack drop = itemEntity.getItemStack();
            itemsCollected += drop.getAmount();
            ItemStack leftover = companion.addToStorage(drop);
            if (leftover.getType() == Material.AIR || leftover.getAmount() == 0) {
                itemEntity.remove();
            } else {
                itemEntity.setItemStack(leftover);
            }
        }

        // Vanilla-accurate: the block still breaks with a weak tool, it just won't drop anything.
        if (itemsCollected == 0 && !reportedWeakTool && !ItemUtil.canMine(tool.getType(), oreType)) {
            companion.notifyOwner("That didn't drop anything - my pickaxe isn't strong enough for " + spokenName + ". Give me a better one!");
            reportedWeakTool = true;
        }
    }

    private void damageTool(Companion companion, ItemStack tool) {
        if (tool.getType() == Material.AIR) return;
        if (!(tool.getItemMeta() instanceof Damageable damageable)) return;
        damageable.setDamage(damageable.getDamage() + 1);
        tool.setItemMeta((org.bukkit.inventory.meta.ItemMeta) damageable);
        int maxDurability = tool.getType().getMaxDurability();
        if (maxDurability > 0 && damageable.getDamage() >= maxDurability) {
            companion.notifyOwner("My " + tool.getType() + " just broke!");
            companion.setTool(null);
        } else {
            companion.setTool(tool);
        }
    }

    private Location findNearestOre(Location origin) {
        World world = origin.getWorld();
        if (world == null) return null;

        Location best = null;
        double bestDist = Double.MAX_VALUE;
        int baseX = origin.getBlockX();
        int baseY = origin.getBlockY();
        int baseZ = origin.getBlockZ();

        for (int dx = -SEARCH_RADIUS; dx <= SEARCH_RADIUS; dx++) {
            for (int dz = -SEARCH_RADIUS; dz <= SEARCH_RADIUS; dz++) {
                int x = baseX + dx;
                int z = baseZ + dz;
                // Never force-load/generate chunks just to search them - skip anything not already loaded.
                if (!world.isChunkLoaded(x >> 4, z >> 4)) continue;

                for (int dy = -MAX_BLOCKS_PER_SEARCH_Y; dy <= MAX_BLOCKS_PER_SEARCH_Y; dy++) {
                    int y = baseY + dy;
                    if (y < world.getMinHeight() || y >= world.getMaxHeight()) continue;

                    Material type = world.getBlockAt(x, y, z).getType();
                    if (oreTypes.contains(type)) {
                        double d = (dx * dx) + (dy * dy) + (dz * dz);
                        if (d < bestDist) {
                            bestDist = d;
                            best = new Location(world, x + 0.5, y, z + 0.5);
                        }
                    }
                }
            }
        }
        return best;
    }

    @Override
    public boolean isComplete(Companion companion) {
        return complete;
    }

    @Override
    public String getName() {
        return "Mining " + spokenName;
    }

    @Override
    public void onCancel(Companion companion) {
        companion.notifyOwner("Stopping mining.");
    }
}
