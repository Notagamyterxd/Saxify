package com.aicompanion.tasks;

import com.aicompanion.companion.Companion;
import com.aicompanion.util.PathfindUtil;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class ReturnTask implements Task {

    private static final double HANDOFF_RANGE = 2.5;
    private static final double SPEED = 1.1;
    private boolean complete = false;

    @Override
    public void tick(Companion companion) {
        Mob mob = companion.getEntity();
        Player owner = companion.getOwner();
        if (mob == null || owner == null) {
            complete = true;
            return;
        }

        double dist = mob.getLocation().distance(owner.getLocation());
        if (dist > HANDOFF_RANGE) {
            PathfindUtil.moveTo(mob, owner.getLocation(), SPEED);
            return;
        }

        PathfindUtil.stop(mob);
        handOverItems(companion, owner);
        complete = true;
    }

    private void handOverItems(Companion companion, Player owner) {
        var storage = companion.getStorage();
        int given = 0;
        for (int i = 0; i < storage.getSize(); i++) {
            ItemStack item = storage.getItem(i);
            if (item == null || item.getType().isAir()) continue;

            var leftover = owner.getInventory().addItem(item);
            if (leftover.isEmpty()) {
                storage.setItem(i, null);
                given++;
            } else {
                // Player's inventory is full: drop the remainder at their feet.
                ItemStack remaining = leftover.values().iterator().next();
                owner.getWorld().dropItemNaturally(owner.getLocation(), remaining);
                storage.setItem(i, null);
            }
        }
        companion.notifyOwner(given > 0
                ? "Here's what I collected!"
                : "I didn't have anything to give you.");
    }

    @Override
    public boolean isComplete(Companion companion) {
        return complete;
    }

    @Override
    public String getName() {
        return "Returning";
    }
}
