package com.aicompanion.tasks;

import com.aicompanion.companion.Companion;

/**
 * A Task represents one behavior the companion is currently running
 * (following, mining, building, guarding, returning...).
 * tick() is called periodically by the CompanionManager scheduler.
 */
public interface Task {

    /** Called repeatedly while this task is active. */
    void tick(Companion companion);

    /** Return true once the task has finished and should be cleared/replaced. */
    boolean isComplete(Companion companion);

    /** Human readable name used in chat feedback / status command. */
    String getName();

    /** Called once when the task is cancelled early (e.g. player says "stop"). */
    default void onCancel(Companion companion) {
    }
}
