package com.aicompanion.util;

import org.bukkit.Material;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class ItemUtil {

    private ItemUtil() {
    }

    // Maps a spoken keyword ("diamond", "iron", "coal"...) to the ore block(s) to look for.
    private static final Map<String, List<Material>> ORE_KEYWORDS = Map.ofEntries(
            Map.entry("diamond", List.of(Material.DIAMOND_ORE, Material.DEEPSLATE_DIAMOND_ORE)),
            Map.entry("iron", List.of(Material.IRON_ORE, Material.DEEPSLATE_IRON_ORE)),
            Map.entry("gold", List.of(Material.GOLD_ORE, Material.DEEPSLATE_GOLD_ORE, Material.NETHER_GOLD_ORE)),
            Map.entry("coal", List.of(Material.COAL_ORE, Material.DEEPSLATE_COAL_ORE)),
            Map.entry("redstone", List.of(Material.REDSTONE_ORE, Material.DEEPSLATE_REDSTONE_ORE)),
            Map.entry("lapis", List.of(Material.LAPIS_ORE, Material.DEEPSLATE_LAPIS_ORE)),
            Map.entry("emerald", List.of(Material.EMERALD_ORE, Material.DEEPSLATE_EMERALD_ORE)),
            Map.entry("copper", List.of(Material.COPPER_ORE, Material.DEEPSLATE_COPPER_ORE)),
            Map.entry("stone", List.of(Material.STONE, Material.COBBLESTONE)),
            Map.entry("wood", List.of(Material.OAK_LOG, Material.BIRCH_LOG, Material.SPRUCE_LOG, Material.JUNGLE_LOG)),
            Map.entry("log", List.of(Material.OAK_LOG, Material.BIRCH_LOG, Material.SPRUCE_LOG, Material.JUNGLE_LOG))
    );

    // Minimum pickaxe tier required to harvest a given ore (index into TIER_ORDER).
    private static final List<Material> TIER_ORDER = List.of(
            Material.WOODEN_PICKAXE, Material.STONE_PICKAXE, Material.IRON_PICKAXE,
            Material.DIAMOND_PICKAXE, Material.NETHERITE_PICKAXE
    );

    private static final Set<Material> NEEDS_IRON_OR_BETTER = Set.of(
            Material.IRON_ORE, Material.DEEPSLATE_IRON_ORE,
            Material.GOLD_ORE, Material.DEEPSLATE_GOLD_ORE, Material.NETHER_GOLD_ORE,
            Material.LAPIS_ORE, Material.DEEPSLATE_LAPIS_ORE,
            Material.DIAMOND_ORE, Material.DEEPSLATE_DIAMOND_ORE,
            Material.EMERALD_ORE, Material.DEEPSLATE_EMERALD_ORE,
            Material.REDSTONE_ORE, Material.DEEPSLATE_REDSTONE_ORE
    );

    // Maps a spoken keyword ("dirt", "gravel", "cobblestone"...) to the clutter blocks to clean up.
    private static final Map<String, List<Material>> CLEAN_KEYWORDS = Map.ofEntries(
            Map.entry("dirt", List.of(Material.DIRT, Material.GRASS_BLOCK, Material.COARSE_DIRT,
                    Material.ROOTED_DIRT, Material.PODZOL, Material.MYCELIUM)),
            Map.entry("gravel", List.of(Material.GRAVEL)),
            Map.entry("sand", List.of(Material.SAND, Material.RED_SAND)),
            Map.entry("cobblestone", List.of(Material.COBBLESTONE, Material.COBBLED_DEEPSLATE)),
            Map.entry("cobble", List.of(Material.COBBLESTONE, Material.COBBLED_DEEPSLATE)),
            Map.entry("netherrack", List.of(Material.NETHERRACK)),
            Map.entry("andesite", List.of(Material.ANDESITE, Material.DIORITE, Material.GRANITE))
    );

    private static final List<Material> ALL_CLUTTER = CLEAN_KEYWORDS.values().stream()
            .flatMap(List::stream)
            .distinct()
            .toList();

    /** Resolve a spoken clean-up word ("dirt", "gravel"...) to block types, or a catch-all if unspecified. */
    public static List<Material> resolveCleanKeyword(String word) {
        if (word == null) {
            return ALL_CLUTTER;
        }
        String key = word.toLowerCase(Locale.ROOT).replaceAll("s$", "");
        if (containsAny(key, "everything", "every", "all", "clutter", "mess", "trash", "etc")) {
            return ALL_CLUTTER;
        }
        List<Material> resolved = CLEAN_KEYWORDS.get(key);
        return resolved != null ? resolved : ALL_CLUTTER;
    }

    /** Scans free-form text for the first recognized clean-up keyword (singular or plural), or null. */
    public static String findCleanWordIn(String text) {
        String lower = text.toLowerCase(Locale.ROOT);
        for (String word : CLEAN_KEYWORDS.keySet()) {
            if (lower.contains(word)) {
                return word;
            }
        }
        return null;
    }

    private static boolean containsAny(String text, String... options) {
        for (String o : options) {
            if (text.contains(o)) return true;
        }
        return false;
    }


    public static List<Material> resolveOreKeyword(String word) {
        String key = word.toLowerCase(Locale.ROOT).replaceAll("s$", "");
        return ORE_KEYWORDS.get(key);
    }

    /** Scans free-form text for the first recognized ore keyword (singular or plural), or null. */
    public static String findOreWordIn(String text) {
        String lower = text.toLowerCase(Locale.ROOT);
        for (String word : ORE_KEYWORDS.keySet()) {
            if (lower.contains(word)) {
                return word;
            }
        }
        return null;
    }

    public static boolean canMine(Material tool, Material ore) {
        if (!NEEDS_IRON_OR_BETTER.contains(ore)) {
            return true; // coal, copper, stone etc. mineable with any pickaxe (or by hand, slowly)
        }
        int tierIndex = TIER_ORDER.indexOf(tool);
        int ironIndex = TIER_ORDER.indexOf(Material.IRON_PICKAXE);
        return tierIndex >= ironIndex;
    }

    public static boolean isPickaxe(Material material) {
        return TIER_ORDER.contains(material);
    }
}
