package com.aicompanion.util;

import org.bukkit.Location;
import org.bukkit.entity.Mob;

public final class PathfindUtil {

    private PathfindUtil() {
    }

    /** Tells the mob to walk toward a location at the given speed multiplier. */
    public static void moveTo(Mob mob, Location target, double speed) {
        if (mob == null || target == null || target.getWorld() == null) return;
        if (!mob.getWorld().equals(target.getWorld())) return;
        mob.getPathfinder().moveTo(target, speed);
    }

    /** Distance (ignoring Y a bit) used to decide "close enough" to stop walking. */
    public static double horizontalDistance(Location a, Location b) {
        double dx = a.getX() - b.getX();
        double dz = a.getZ() - b.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    public static boolean isCloseEnough(Location a, Location b, double range) {
        if (a.getWorld() == null || b.getWorld() == null || !a.getWorld().equals(b.getWorld())) return false;
        return a.distanceSquared(b) <= range * range;
    }

    /** Makes the mob stop actively walking (does not clear the target). */
    public static void stop(Mob mob) {
        if (mob == null) return;
        mob.getPathfinder().stopPathfinding();
    }

    /** Faces the mob toward a location without moving it. */
    public static void lookAt(Mob mob, Location target) {
        if (mob == null || target == null) return;
        Location loc = mob.getLocation();
        double dx = target.getX() - loc.getX();
        double dz = target.getZ() - loc.getZ();
        float yaw = (float) (Math.toDegrees(Math.atan2(-dx, dz)));
        mob.setRotation(yaw, mob.getLocation().getPitch());
    }
}
